// Below is the objects array as well as the getting stuff from html an fthe for loop to go through the objects

let carts = document.querySelectorAll('.add-cart');
console.log("Moha");
let products  =[ 
   { name : "cover pg",
    tag: "greyhoddie",
    price: 30,
    inCart: 0},
    
    { name : "greytshirt",
    tag: "greytshirt",
    price: 20,
    inCart: 0},
    
    { name : "greyhoddie",
    tag: "greyhoddie",
    price: 67,
    inCart: 0},
    
    { name : "greytshirt",
    tag: "greytshirt",
    price: 80,
    inCart: 0},]
for (let i =0; i< carts.length; i++) {
    carts[i].addEventListener('click', () =>{
        cartNumbers(products[i]);
        totalCost(products[i]);
        //console.log(products[i].tag);
        //console.log(products[i].inCart);
})}

// The 1 first function 
function cartNumbers(product) {
    console.log("MOha");
   let productNumbers =localStorage.getItem('cartNumbers')
   productNumbers = parseInt(productNumbers);
   
   if (productNumbers) {
       localStorage.setItem('cartNumbers', productNumbers +1)
       document.querySelector('.cart span').textContent = 
       productNumbers+1;
   
   }
       else {
           localStorage.setItem('cartNumbers',1);
           document.querySelector('.cart span').textContent = 1;

       }
       setItems(product);
        }

// The 2 second function with  loading to update the Carts on top
function onLoadCartNumbers() {
    let productNumbers =localStorage.getItem('cartNumbers');
    if (productNumbers) {
        document.querySelector('.cart span'). textContent =productNumbers;
    }
}
// The 3 third function 
function setItems(product) {
let cartItems =localStorage.getItem("productsIncart");
cartItems = JSON.parse(cartItems);
console.log("My cartItems are ",cartItems);

if (cartItems != null) {
    if (cartItems[product.tag] == undefined){
        cartItems =  {
            ...cartItems,
                [product.tag]:product
            }
        }
    
    cartItems[product.tag].inCart += 1;
}
else {
    product.inCart =1;
    cartItems = {
        [product.tag]: product
    }
}






localStorage.setItem("productsIncart", JSON.stringify(cartItems));

}







// The 4 fourth functin 
function totalCost(product) {
    let cartcost  = localStorage.getItem('totalCost');
    //console.log("My cartCost is", cartcost);
    //console.log(typeof cartcost);
  if (cartcost != null) {
    cartcost =parseInt(cartcost);
    localStorage.setItem("totalCost", cartcost + product.price);}
else {
    localStorage.setItem("totalCost", product.price);}
}

// The 5 fifth function 
function displayCart() {
    let cartItems = localStorage.getItem('productsIncart');
    cartItems = JSON.parse(cartItems);
    let productContainer =document.querySelector
    (".products");
    let cartcost  = localStorage.getItem('totalCost');
    console.log(cartItems);
    console.log(cartItems);
    if(cartItems && productContainer ) {
        
        productContainer.innerHTML =

        '';
        Object.values(cartItems).map(item=> {
            productContainer.innerHTML +=`
            <div class="product">
            <ion-icon name= "close-circle"></ion-icon>
            <image             src="./images/${item.tag}.jpg"
            width ="75";
            height = "35";>
            <span class="tag">${item.name}</span><div class =="price">${item.price},00</div>
              <div class="quantity"> 
              <ion-icon name="chevron-back-outline"></ion-icon>
              <span>  ${item.inCart} </span>
              <ion-icon name="arrow-up-outline"></ion-icon>
              </div>
              <div class="total">
              $${item.inCart * item.price},00
              
              
              </div>
            `;
        });
            productContainer.innerHTML += `
            <div class ="basketToalContainer">
            <h4 class = "basketTotalTitle">
            Basket Total </h4>
            <h4  class= "basketTotal" >
            $${cartcost},00

            </h4>
  
            `;
    
    }
    deleteButtons();
}
//  6 Sixth function
    function deleteButtons(){
        
    let deleteButtons =document.querySelectorAll('.product ion-icon');
   
    console.log(deleteButtons);
    
    console.log("deleteButtons ");
let productName;
    
    for (i=0; i< deleteButtons.length; i++) {
        deleteButtons[i].addEventListener('click', () =>{
            console.log("clicked");
       
    });
    }
    



    }






/*function  displayCart(){
let cartItems = localStorage.getItem("productsIncart");
//cartItem =JSON.parse(cartItems);
let productContainer =document.querySelector(".products-container");

if (cartItems && productContainer) {
   productContainer.innerHTML ='';
   Object.values(cartItems).map(item => {
    productContainer.innerHTML += `
       <div class="product"> 
        <ion-icon name ="close-circle"></ion-icon>
           <img src ="./images/${item.tag}.jpg">
               <span>${item.name}</span>
         </div>
         <div class="price"> ${item.price}</div>
         <div class ="quantity">
         <ion-icon class ="decrease"
         name ="arrow-dropleft-circle" ></ion-icon>
         <span>${item.inCart}</span>
         <ionicon class="increase"
         name="arrow-dropright-circle" ></ion-icon>
         <div class= "total">
             $${item.inCart + item.price}, 00
         </div>`
         ;});
   productContainer.innerHTML +=
   `<div class= "basketTotalContainer">
       <h4 class ="basketTotalTitle">
           Basket Total
       </h4>
       <h4 class= "basketTotal"> $$ {cartCost},00</h4>;`}}*/
   onLoadCartNumbers();
   
   displayCart();
